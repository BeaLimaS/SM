

# Compile w/ debug symbols

gcc lab10_1.c calcula_f.s -o calcula_f

