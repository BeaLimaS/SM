

# Compile w/ debug symbols

gcc lab10_2.c fibo_cycle.s fibo_recursive.s -o fibonacci
